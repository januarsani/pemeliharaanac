import React from 'react'
import ScanPage from './ScanPage'
import Dashboard from './Dashboard'

export default function App(){
  const [view, setView] = React.useState('scan')

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">AC</div>
          <div className="brand-text">
            <div className="title">Kartu Pemeliharaan</div>
            <div className="subtitle">AC Digital</div>
          </div>
        </div>

        <nav className="nav">
          <button className={view==='scan'?'active':''} onClick={()=>setView('scan')}>Scan</button>
          <button className={view==='dashboard'?'active':''} onClick={()=>setView('dashboard')}>Data Pemeliharaan</button>
        </nav>

        <div className="footer-note">Versi: Online • Supabase</div>
      </aside>

      <main className="main">
        {view==='scan' ? <ScanPage /> : <Dashboard />}
      </main>
    </div>
  )
}
