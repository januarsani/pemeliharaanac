import React, { useEffect, useState } from 'react';
import { fetchMonthlyReport } from './api';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

export default function Dashboard(){
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth()+1);
  const [report, setReport] = useState({ items: [] });
  const chartRef = React.useRef(null);

  useEffect(()=>{ load(); }, [year, month]);

  async function load(){
    try {
      const r = await fetchMonthlyReport(year, month);
      setReport(r);
      if (chartRef.current) chartRef.current.destroy?.();
      const ctx = document.getElementById('chart').getContext('2d');
      chartRef.current = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: r.items.map(i=>i.ac_id),
          datasets: [{ label: 'Total biaya (Rp)', data: r.items.map(i=>i.total_cost) }]
        },
        options: { responsive:true, maintainAspectRatio:false }
      });
    } catch (err) {
      console.error(err);
    }
  }

  const totalAll = report.items.reduce((s,i)=>s + Number(i.total_cost || 0), 0);
  const totalTimes = report.items.reduce((s,i)=>s + Number(i.times || 0), 0);

  return (
    <div className="page">
      <div className="header-row">
        <div>
          <h3>Ringkasan Bulanan</h3>
          <div className="muted">Laporan untuk presentasi ke atasan</div>
        </div>

        <div className="filters">
          <label>Tahun <input type="number" value={year} onChange={e=>setYear(Number(e.target.value))} /></label>
          <label style={{marginLeft:8}}>Bulan <input type="number" value={month} onChange={e=>setMonth(Number(e.target.value))} min={1} max={12} /></label>
        </div>
      </div>

      <div className="cards">
        <div className="stat-card">
          <div className="stat-title">Total Biaya</div>
          <div className="stat-value">Rp {totalAll.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-title">Total Pekerjaan</div>
          <div className="stat-value">{totalTimes}</div>
        </div>
      </div>

      <div className="chart-wrap">
        <canvas id="chart"></canvas>
      </div>

      <h4 style={{marginTop:18}}>Rincian Per AC</h4>
      <table className="table">
        <thead><tr><th>AC ID</th><th>Jumlah</th><th>Total Biaya</th></tr></thead>
        <tbody>
          {report.items.map(it=>(
            <tr key={it.ac_id}><td>{it.ac_id}</td><td>{it.times}</td><td>Rp {Number(it.total_cost).toLocaleString()}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
