import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!SUPABASE_URL || !SUPABASE_ANON) {
  console.warn('Supabase env not set. Copy .env.example to .env and set VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY')
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON)

export async function insertRecord(payload){
  const { data, error } = await supabase.from('records').insert([payload]).select()
  if (error) throw error
  return data
}

export async function fetchRecordsRange(start, end){
  const { data, error } = await supabase
    .from('records')
    .select('*')
    .gte('date', start)
    .lte('date', end)
    .order('date', { ascending: false })
  if (error) throw error
  return data
}

export async function fetchMonthlyReport(year, month){
  const start = `${year}-${String(month).padStart(2,'0')}-01`
  const endDate = new Date(year, month, 0).getDate()
  const end = `${year}-${String(month).padStart(2,'0')}-${String(endDate).padStart(2,'0')}`
  const { data, error } = await supabase
    .from('records')
    .select('ac_id, cost')
    .gte('date', start)
    .lte('date', end)
  if (error) throw error
  const map = {}
  data.forEach(r => {
    const id = r.ac_id || '(unknown)'
    const c = Number(r.cost) || 0
    if (!map[id]) map[id] = { times:0, total:0 }
    map[id].times += 1
    map[id].total += c
  })
  const items = Object.entries(map).map(([ac_id, v])=>({ ac_id, times: v.times, total_cost: v.total }))
  items.sort((a,b)=>b.total_cost - a.total_cost)
  return { start, end, items }
}
