import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { insertRecord } from './api';

export default function ScanPage(){
  const [scannedId, setScannedId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [description, setDescription] = useState('');
  const [cost, setCost] = useState('0');
  const [status, setStatus] = useState('Siap');
  const scannerRef = useRef(null);

  useEffect(()=>{
    const config = { fps: 10, qrbox: 250 };
    const html5QrCode = new Html5Qrcode('reader');
    scannerRef.current = html5QrCode;
    html5QrCode.start({ facingMode: 'environment' }, config, (decoded) => {
      setScannedId(decoded);
      html5QrCode.pause();
      setStatus('Terdeteksi: ' + decoded);
    }).catch(err => {
      console.error('QR start failed', err);
      setStatus('Camera error: '+String(err));
    });
    return ()=> html5QrCode.stop().catch(()=>{});
  }, []);

  async function submit(e){
    e.preventDefault();
    if (!scannedId) {
      setStatus('Silakan scan ID AC atau isi manual.');
      return;
    }
    setStatus('Menyimpan...');
    try {
      const payload = { ac_id: scannedId, date, description, cost: Number(cost) };
      await insertRecord(payload);
      setStatus('Tersimpan ✅');
      setDescription(''); setCost('0');
      scannerRef.current?.resume();
      setScannedId('');
    } catch (err) {
      console.error(err);
      setStatus('Error: '+err.message);
    }
  }

  return (
    <div className="page">
      <div className="card split">
        <div style={{flex:1}}>
          <h3>Scan AC</h3>
          <div id="reader" style={{width:'100%', maxWidth:480, aspectRatio:'4/3', borderRadius:8, overflow:'hidden', background:'#000'}}></div>
          <p className="muted">Hasil scan: <strong>{scannedId || '-'}</strong></p>
        </div>

        <form className="form" onSubmit={submit} style={{flex:1}}>
          <label>Tanggal</label>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} required />

          <label>Uraian Pekerjaan</label>
          <textarea value={description} onChange={e=>setDescription(e.target.value)} rows={4} placeholder="Contoh: Cuci AC + vacuum"></textarea>

          <label>Nominal (Rp)</label>
          <input type="number" value={cost} onChange={e=>setCost(e.target.value)} />

          <div style={{display:'flex', gap:10, marginTop:8}}>
            <button className="btn primary" type="submit">Simpan</button>
            <button type="button" className="btn" onClick={()=>{ setScannedId(''); setStatus('Siap'); scannerRef.current?.resume(); }}>Reset</button>
          </div>

          <p className="muted">Status: {status}</p>
        </form>
      </div>

      <div style={{marginTop:12}} className="hint">
        <strong>Tips:</strong> pastikan kamera diarahkan ke QR/Barcode, atau ketik manual ID AC jika QR tidak terbaca.
      </div>
    </div>
  )
}
